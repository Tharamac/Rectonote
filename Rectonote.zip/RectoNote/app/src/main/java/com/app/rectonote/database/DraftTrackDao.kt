package com.app.rectonote.database

import androidx.room.Dao

@Dao
interface DraftTrackDao{

}