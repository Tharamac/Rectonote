package com.app.rectonote.database

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel

class ProjectDatabaseViewModel(
    val database: ProjectDao
) : ViewModel(){

}