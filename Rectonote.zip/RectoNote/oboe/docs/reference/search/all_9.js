var searchData=
[
  ['latencytuner',['LatencyTuner',['../classoboe_1_1_latency_tuner.html',1,'oboe::LatencyTuner'],['../classoboe_1_1_latency_tuner.html#a0263b9a55825c0a403653b2b508073ea',1,'oboe::LatencyTuner::LatencyTuner(AudioStream &amp;stream)'],['../classoboe_1_1_latency_tuner.html#ab437bd10605af9e5733d043f8adc0b43',1,'oboe::LatencyTuner::LatencyTuner(AudioStream &amp;stream, int32_t maximumBufferSize)']]],
  ['launchstopthread',['launchStopThread',['../classoboe_1_1_audio_stream.html#aa5f4801cca6877eeaa4735b93933269d',1,'oboe::AudioStream']]],
  ['lowlatency',['LowLatency',['../namespaceoboe.html#a1068781f3920654b1bfd7ed136468184a611907b5ab1865515c35357efa41a9b9',1,'oboe']]]
];
