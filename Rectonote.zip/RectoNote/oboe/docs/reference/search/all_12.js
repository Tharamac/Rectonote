var searchData=
[
  ['value',['value',['../classoboe_1_1_result_with_value.html#a45f5c99a2c9f8fbaca502276f7ebb434',1,'oboe::ResultWithValue']]],
  ['version',['Version',['../structoboe_1_1_version.html',1,'oboe']]],
  ['voicecommunication',['VoiceCommunication',['../namespaceoboe.html#a4477ed232b02e2694d9309baf55a8f06a1862e72c9730c448fbec6f61a5d8234d',1,'oboe::VoiceCommunication()'],['../namespaceoboe.html#a4477ed232b02e2694d9309baf55a8f06a5bad8854288c956062ec1d4d7c14fed6',1,'oboe::VoiceCommunication()']]],
  ['voicecommunicationsignalling',['VoiceCommunicationSignalling',['../namespaceoboe.html#a104ee8396c173fefac429759ea3c21a0a404f62633744bf4da0c6a27a2b78ce74',1,'oboe']]],
  ['voiceperformance',['VoicePerformance',['../namespaceoboe.html#a4477ed232b02e2694d9309baf55a8f06ad19edec0a23e435c774bf3bbcf1d999c',1,'oboe']]],
  ['voicerecognition',['VoiceRecognition',['../namespaceoboe.html#a4477ed232b02e2694d9309baf55a8f06af6e440b4e9edf49afe18aa4be77be6fc',1,'oboe']]]
];
