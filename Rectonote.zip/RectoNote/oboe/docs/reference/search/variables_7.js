var searchData=
[
  ['text',['Text',['../structoboe_1_1_version.html#a2c86e578b827fbca5f40c460a7754503',1,'oboe::Version']]]
];
