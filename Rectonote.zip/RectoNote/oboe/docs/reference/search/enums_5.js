var searchData=
[
  ['result',['Result',['../namespaceoboe.html#a486512e787b609c80ba4436f23929af1',1,'oboe']]]
];
