var searchData=
[
  ['i16',['I16',['../namespaceoboe.html#a92afc593e856571aacbfd02e57075df6abcd774f891b5f9df7099f3ea75dadf8d',1,'oboe']]],
  ['input',['Input',['../namespaceoboe.html#af2147500089212955498a08ef2edb5aea324118a6721dd6b8a9b9f4e327df2bf5',1,'oboe']]],
  ['inputpreset',['InputPreset',['../namespaceoboe.html#a4477ed232b02e2694d9309baf55a8f06',1,'oboe']]],
  ['invalid',['Invalid',['../namespaceoboe.html#a92afc593e856571aacbfd02e57075df6a4bbb8f967da6d1a610596d7257179c2b',1,'oboe']]],
  ['isaaudiorecommended',['isAAudioRecommended',['../classoboe_1_1_audio_stream_builder.html#a622732bbe5c6577356d749f7dc2108df',1,'oboe::AudioStreamBuilder']]],
  ['isaaudiosupported',['isAAudioSupported',['../classoboe_1_1_audio_stream_builder.html#a18e7b5f7554a4c2ca763e35e8117d699',1,'oboe::AudioStreamBuilder']]],
  ['isatmaximumbuffersize',['isAtMaximumBufferSize',['../classoboe_1_1_latency_tuner.html#a45c013fd6787ad09d328385d6314c4d4',1,'oboe::LatencyTuner']]],
  ['ischannelconversionallowed',['isChannelConversionAllowed',['../classoboe_1_1_audio_stream_base.html#aa4ec3aa76e69350fbce6f00786211495',1,'oboe::AudioStreamBase']]],
  ['isdatacallbackenabled',['isDataCallbackEnabled',['../classoboe_1_1_audio_stream.html#add85011ba825f74931deeb92c5edf831',1,'oboe::AudioStream']]],
  ['isformatconversionallowed',['isFormatConversionAllowed',['../classoboe_1_1_audio_stream_base.html#ace3625a7332bf02a86818fdf63fcccb4',1,'oboe::AudioStreamBase']]],
  ['isxruncountsupported',['isXRunCountSupported',['../classoboe_1_1_audio_stream.html#a43d8a098440cde28f4ee8bedd6d107c4',1,'oboe::AudioStream']]]
];
