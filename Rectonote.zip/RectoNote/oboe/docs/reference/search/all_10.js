var searchData=
[
  ['text',['Text',['../structoboe_1_1_version.html#a2c86e578b827fbca5f40c460a7754503',1,'oboe::Version']]],
  ['tune',['tune',['../classoboe_1_1_latency_tuner.html#ad2be756965e6a9af3114008eda892174',1,'oboe::LatencyTuner']]]
];
