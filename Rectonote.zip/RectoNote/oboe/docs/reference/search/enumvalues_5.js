var searchData=
[
  ['game',['Game',['../namespaceoboe.html#a104ee8396c173fefac429759ea3c21a0a63d72051e901c069f8aa1b32aa0c43bb',1,'oboe']]],
  ['generic',['Generic',['../namespaceoboe.html#a4477ed232b02e2694d9309baf55a8f06a0ba6f369e7f8a700c14afe2992290544',1,'oboe']]]
];
