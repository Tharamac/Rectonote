var searchData=
[
  ['channelcount',['ChannelCount',['../classoboe_1_1_default_stream_values.html#ad5dce538d5963c81bf58350ab730962d',1,'oboe::DefaultStreamValues']]]
];
