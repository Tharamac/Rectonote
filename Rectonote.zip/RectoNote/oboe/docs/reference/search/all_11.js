var searchData=
[
  ['unprocessed',['Unprocessed',['../namespaceoboe.html#a4477ed232b02e2694d9309baf55a8f06acad9424158aefae0af7975901b11d85f',1,'oboe']]],
  ['unspecified',['Unspecified',['../namespaceoboe.html#a522e6806948369987639a0d1df03c029a946257a568f77c12df4fc4c49125da76',1,'oboe::Unspecified()'],['../namespaceoboe.html#a522e6806948369987639a0d1df03c029a6fcdc090caeade09d0efd6253932b6f5',1,'oboe::Unspecified()'],['../namespaceoboe.html#a522e6806948369987639a0d1df03c029a6fcdc090caeade09d0efd6253932b6f5',1,'oboe::Unspecified()']]],
  ['updateframesread',['updateFramesRead',['../classoboe_1_1_audio_stream.html#a462358ddab709c79d1a7968d6d55b727',1,'oboe::AudioStream']]],
  ['updateframeswritten',['updateFramesWritten',['../classoboe_1_1_audio_stream.html#a64ad978c5f70ced17ef5a96605496515',1,'oboe::AudioStream']]],
  ['usage',['Usage',['../namespaceoboe.html#a104ee8396c173fefac429759ea3c21a0',1,'oboe']]],
  ['usesaaudio',['usesAAudio',['../classoboe_1_1_audio_stream.html#a15cdaaaa4c1e8da322d6da33334c8147',1,'oboe::AudioStream']]]
];
