var searchData=
[
  ['shared',['Shared',['../namespaceoboe.html#a8330247b25429953a08354f41834d520aa6156ea9d66fef24e87e841fbabf7cca',1,'oboe']]],
  ['sonification',['Sonification',['../namespaceoboe.html#a2a3cec6f021c1a324df60273710c604ba0885eef555037e94a7cf39fe683c2799',1,'oboe']]],
  ['speech',['Speech',['../namespaceoboe.html#a2a3cec6f021c1a324df60273710c604ba3dc48a4b4619aa4edd1da7b937b4dcd1',1,'oboe']]],
  ['stereo',['Stereo',['../namespaceoboe.html#a522e6806948369987639a0d1df03c029a534e646333ca7568317b171ea96b89ba',1,'oboe']]]
];
