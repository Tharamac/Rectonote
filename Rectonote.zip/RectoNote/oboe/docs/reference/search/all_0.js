var searchData=
[
  ['aaudio',['AAudio',['../namespaceoboe.html#a92972414867c81d5974cb2ed7abefbf6a99780b1e8d754eb42abed0ca5253e55b',1,'oboe']]],
  ['alarm',['Alarm',['../namespaceoboe.html#a104ee8396c173fefac429759ea3c21a0a46c4c4d980dfe025ae5b35aa0011dde4',1,'oboe']]],
  ['allocate',['Allocate',['../namespaceoboe.html#a5752250c10e96179e3618d7f72937eafa8485ca716c8cd4aafee372fd7028c123',1,'oboe']]],
  ['assistanceaccessibility',['AssistanceAccessibility',['../namespaceoboe.html#a104ee8396c173fefac429759ea3c21a0a639ffd54516c1a84a288a363c9469df8',1,'oboe']]],
  ['assistancenavigationguidance',['AssistanceNavigationGuidance',['../namespaceoboe.html#a104ee8396c173fefac429759ea3c21a0ade058a1314f9a8504593259ff4f21a1e',1,'oboe']]],
  ['assistancesonification',['AssistanceSonification',['../namespaceoboe.html#a104ee8396c173fefac429759ea3c21a0a1ce57a0572748beebfc0c664ca1077e7',1,'oboe']]],
  ['assistant',['Assistant',['../namespaceoboe.html#a104ee8396c173fefac429759ea3c21a0a9b1363da9503dbd4142c0274a88e8d4b',1,'oboe']]],
  ['audioapi',['AudioApi',['../namespaceoboe.html#a92972414867c81d5974cb2ed7abefbf6',1,'oboe']]],
  ['audioformat',['AudioFormat',['../namespaceoboe.html#a92afc593e856571aacbfd02e57075df6',1,'oboe']]],
  ['audiostream',['AudioStream',['../classoboe_1_1_audio_stream.html',1,'oboe::AudioStream'],['../classoboe_1_1_audio_stream.html#a8ebb587a07bf62c864fd62c63b241fd4',1,'oboe::AudioStream::AudioStream()']]],
  ['audiostreambase',['AudioStreamBase',['../classoboe_1_1_audio_stream_base.html',1,'oboe::AudioStreamBase'],['../classoboe_1_1_audio_stream_base.html#aa6b103e1b0f808bbc4949d56f0829f98',1,'oboe::AudioStreamBase::AudioStreamBase()']]],
  ['audiostreambuilder',['AudioStreamBuilder',['../classoboe_1_1_audio_stream_builder.html',1,'oboe']]],
  ['audiostreamcallback',['AudioStreamCallback',['../classoboe_1_1_audio_stream_callback.html',1,'oboe']]],
  ['api_20reference',['API reference',['../index.html',1,'']]]
];
