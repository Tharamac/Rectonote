var searchData=
[
  ['latencytuner',['LatencyTuner',['../classoboe_1_1_latency_tuner.html',1,'oboe']]]
];
