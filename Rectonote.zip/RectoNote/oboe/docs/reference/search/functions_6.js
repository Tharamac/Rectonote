var searchData=
[
  ['latencytuner',['LatencyTuner',['../classoboe_1_1_latency_tuner.html#a0263b9a55825c0a403653b2b508073ea',1,'oboe::LatencyTuner::LatencyTuner(AudioStream &amp;stream)'],['../classoboe_1_1_latency_tuner.html#ab437bd10605af9e5733d043f8adc0b43',1,'oboe::LatencyTuner::LatencyTuner(AudioStream &amp;stream, int32_t maximumBufferSize)']]],
  ['launchstopthread',['launchStopThread',['../classoboe_1_1_audio_stream.html#aa5f4801cca6877eeaa4735b93933269d',1,'oboe::AudioStream']]]
];
