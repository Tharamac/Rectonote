---
name: Bug report
about: Create a report to help us improve
title: ''
labels: bug
assignees: ''

---

Android Version(s):
Android Device(s):
Oboe Version:

**Short Description**

**Steps To Reproduce**

**Expected behavior**

**Actual behavior**

**Additional context**

If applicable, please attach a recording of the sound.
