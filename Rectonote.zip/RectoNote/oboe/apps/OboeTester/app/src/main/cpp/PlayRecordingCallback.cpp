/*
 * Copyright 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "PlayRecordingCallback.h"

/**
 * Called when the stream is ready to process audio.
 */
oboe::DataCallbackResult PlayRecordingCallback::onAudioReady(
        oboe::AudioStream *audioStream,
        void *audioData,
        int numFrames) {
    float *floatData = (float *)audioData;
    // Read stored data into the buffer provided.
    int32_t framesRead = mRecording->read(floatData, numFrames);
    // LOGI("%s() framesRead = %d, numFrames = %d", __func__, framesRead, numFrames);
    return framesRead > 0
           ? oboe::DataCallbackResult::Continue
           : oboe::DataCallbackResult::Stop;
}
