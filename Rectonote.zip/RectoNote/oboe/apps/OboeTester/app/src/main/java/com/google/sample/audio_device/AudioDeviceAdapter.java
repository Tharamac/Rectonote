package com.google.sample.audio_device;
/*
 * Copyright 2017 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.google.sample.oboe.manualtest.R;

/**
 * Provides views for a list of audio devices. Usually used as an Adapter for a Spinner or ListView.
 */
public class AudioDeviceAdapter extends ArrayAdapter<AudioDeviceListEntry> {

    public AudioDeviceAdapter(Context context) {
        super(context, R.layout.audio_devices);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return getDropDownView(position, convertView, parent);
    }

    @Override
    public View getDropDownView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View rowView = convertView;
        if (rowView == null) {
            LayoutInflater inflater = LayoutInflater.from(parent.getContext());
            rowView = inflater.inflate(R.layout.audio_devices, parent, false);
        }

        TextView deviceName = (TextView) rowView.findViewById(R.id.device_name);
        AudioDeviceListEntry deviceInfo = getItem(position);
        deviceName.setText(deviceInfo.getName());

        return rowView;
    }
}
